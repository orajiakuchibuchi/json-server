module.exports = {
    create : async (data) => { },
    
    getAll : async () => {}
}
  