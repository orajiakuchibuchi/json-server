window.onload = () => {
    console.log("Loaded")
}
